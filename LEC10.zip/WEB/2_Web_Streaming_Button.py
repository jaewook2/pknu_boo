from flask import Flask, render_template, Response, url_for, redirect
from PIL import ImageFont, ImageDraw, Image
import cv2
import numpy as np

app = Flask(__name__)
capture = cv2.VideoCapture(0)                      
capture.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
capture.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
global push_btn
push_btn = True                         

def gen_frames():  
    global push_btn                        
    while True:                        
        ref, frame = capture.read()                 
        if not ref:                                 
            break                                   
        else:
            if push_btn:                           
                frame = np.zeros([480, 640, 3], dtype="uint8")     
                frame = Image.fromarray(frame)                  
                frame = np.array(frame)
            ref, buffer = cv2.imencode('.jpg', frame)            
            frame = buffer.tobytes()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')  
@app.route('/')
def index():
    global push_btn                                
    return render_template('index10_2.html', push_btn=push_btn)      

@app.route('/video_feed')
def video_feed():
    return Response(gen_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/push_switch')
def push_switch():                               
    global push_btn   
    push_btn = not push_btn        
    return redirect(url_for('index'))

if __name__ == "__main__":  
    app.run(host="localhost", port = "8080")

