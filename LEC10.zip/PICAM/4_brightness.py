import picamera
import time

camera = picamera.PiCamera()
camera.start_preview()
time.sleep(5)
camera.stop_preview()
camera.capture("/home/boo/Desktop/PKNU/Lec10/4_bright.jpg")


camera.brightness = 20
camera.start_preview()
time.sleep(5)
camera.stop_preview()
camera.capture("/home/boo/Desktop/PKNU/Lec10/4_dark.jpg")

