from flask import Flask, render_template, Response, url_for, redirect
from PIL import ImageFont, ImageDraw, Image
import cv2
import numpy as np

app = Flask(__name__)
capture = cv2.VideoCapture(0)                      
capture.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
capture.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
global is_detected, push_btn, cnt_record, max_cnt_record        
is_detected = False              
push_btn = False
cnt_record = 0                                      
max_cnt_record = 30                                 
face_cascade = cv2.CascadeClassifier('haarcascade/haarcascade_frontalface_default.xml')

def gen_frames():  
    global is_detected, push_btn, cnt_record, max_cnt_record      
    while True:                                     
        ref, frame = capture.read()                 
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)  
        faces = face_cascade.detectMultiScale(gray, scaleFactor= 1.5, minNeighbors=3, minSize=(20,20))
        
        if len(faces) :                     
            is_detected = True              
            cnt_record = max_cnt_record     
        else:                               
            cnt_record -= 1                 
            if cnt_record == 0:             
                is_detected = False         
        if not ref:                         
            break                          
        else:
            if not is_detected and push_btn:                        
                frame = np.zeros([480, 640, 3], dtype="uint8")      
                frame = Image.fromarray(frame)                  
                frame = np.array(frame)
            elif is_detected or not push_btn:                       
                frame = Image.fromarray(frame)                  
                frame = np.array(frame)
            ref, buffer = cv2.imencode('.jpg', frame)            
            frame = buffer.tobytes()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')  

@app.route('/')
def index():
    global push_btn                                 
    return render_template('index10_5.html', push_btn=push_btn)             
@app.route('/push_switch')
def push_switch():                                  
    global push_btn                                 
    push_btn = not push_btn                         
    return redirect(url_for('index'))

@app.route('/video_feed')
def video_feed():
    return Response(gen_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

if __name__ == "__main__":  
    app.run(host="localhost", port = "8080")
