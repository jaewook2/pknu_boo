import picamera
import time

camera = picamera.PiCamera()

camera.start_preview()
camera.start_recording("/home/boo/Desktop/PKNU/Lec10/6_record.h264")
camera.wait_recording(10)
camera.stop_preview()
camera.stop_recording()
