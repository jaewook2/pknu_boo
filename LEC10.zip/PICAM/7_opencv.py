import cv2
import numpy as np

cap = cv2.VideoCapture(0)
ret, img = cap.read()
cap.release()

cv2.imshow('capture_img', img)
cv2.waitKey(0)
cv2.imwrite('7_capture_img.jpg', img)


img_resize = cv2.resize(img, dsize=(640, 480))
cv2.imshow('capture_img_resize', img_resize)
cv2.waitKey(0)
cv2.imwrite('7_capture_img_resize.jpg', img_resize)

img_gray = cv2.cvtColor(img_resize, cv2.COLOR_BGR2GRAY)
cv2.imshow('capture_img_resize_gray', img_gray)
cv2.waitKey(0)
cv2.imwrite('7_capture_img_resize_gray.jpg', img_gray)
