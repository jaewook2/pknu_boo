import picamera
import time

camera = picamera.PiCamera()

camera.start_preview()

for i in range (5):
	time.sleep(5)
	camera.capture("/home/boo/Desktop/PKNU/Lec10/2_capture%d.jpg" %i)

camera.stop_preview()
