import picamera
import time

camera = picamera.PiCamera()
camera.start_preview()
time.sleep(5)
camera.stop_preview()
camera.capture("/home/boo/Desktop/PKNU/Lec10/3_origin.jpg")

camera.resolution = (920, 480)
camera.start_preview()
time.sleep(5)
camera.stop_preview()
camera.capture("/home/boo/Desktop/PKNU/Lec10/3_resolution.jpg")

camera.rotation = 180
camera.start_preview()
time.sleep(5)
camera.stop_preview()
camera.capture("/home/boo/Desktop/PKNU/Lec10/3_rotation.jpg")

