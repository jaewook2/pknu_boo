import picamera
import time

camera = picamera.PiCamera()

camera.annotate_text_size = 30
camera.annotate_background = picamera.Color('blue')
camera.annotate_foreground = picamera.Color('yellow')
camera.annotate_text = "Embedded System Design"

camera.start_preview()
time.sleep(5)
camera.stop_preview()

camera.capture("/home/boo/Desktop/PKNU/Lec10/5_annot.jpg")
