
from flask import Flask, render_template, Response, url_for, redirect
from PIL import ImageFont, ImageDraw, Image
import cv2
import numpy as np


app = Flask(__name__)
global is_capture, is_record, start_record           
capture = cv2.VideoCapture(0)                      
fourcc = cv2.VideoWriter_fourcc(*'XVID')          
capture.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
capture.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
is_record = False
is_capture = False
start_record = False                                   

def gen_frames():  
    global is_record, start_record, is_capture, video  
    while True:                                    
        ref, frame = capture.read()  
        if not ref:                    
            break                      
        else:
            frame = Image.fromarray(frame)    
            frame = np.array(frame)
            ref, buffer = cv2.imencode('.jpg', frame)            
            frame1 = frame              
            frame = buffer.tobytes()
            if start_record == True and is_record == False:  
                is_record = True           
                start_record = False        
                video = cv2.VideoWriter("record .avi", fourcc, 15, (frame1.shape[1], frame1.shape[0]))
            elif start_record == True and is_record == True: 
                is_record = False      
                start_record = False
                video.release()         
            elif is_capture:       
                is_capture = False
                cv2.imwrite("record_capture.png", frame1)  
                
            if is_record == True:                 
                video.write(frame1)
    
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n') 

@app.route('/')
def index():
    global is_record
    return render_template('index10_4.html', is_record=is_record)            

@app.route('/video_feed')
def video_feed():
    return Response(gen_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/push_record')
def push_record():                      
    global start_record                 
    start_record = not start_record     
    return redirect(url_for('index'))

@app.route('/push_capture')
def push_capture():                    
    global is_capture                   
    is_capture = True                   
    return redirect(url_for('index'))

if __name__ == "__main__":  
    app.run(host="localhost", port = "8080")

